package com.tcs.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day11SpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day11SpringbootApplication.class, args);
	}

}
